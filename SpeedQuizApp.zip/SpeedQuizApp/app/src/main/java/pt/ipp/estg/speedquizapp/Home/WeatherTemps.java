package pt.ipp.estg.speedquizapp.Home;

public class WeatherTemps {
    private Weather main;

    public WeatherTemps(Weather main) {
        this.main = main;
    }

    public Weather getMain() {
        return main;
    }

    public void setMain(Weather main) {
        this.main = main;
    }
}

package pt.ipp.estg.speedquizapp.Home;

public class Weather {
    private float temp;

    public Weather(float temp) {
        this.temp = temp;
    }

    public float getTemp() {
        return temp;
    }

    public void setTemp(float temp) {
        this.temp = temp;
    }
}

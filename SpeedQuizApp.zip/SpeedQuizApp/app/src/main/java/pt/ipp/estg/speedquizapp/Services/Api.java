package pt.ipp.estg.speedquizapp.Services;

import pt.ipp.estg.speedquizapp.Home.DaysWeather;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Path;
import retrofit2.http.Query;

public interface Api {

    @GET("forecast")
    Call<DaysWeather> getWeather(
            @Query("lat") float lat,
            @Query("lon") float lon,
            @Query("appid") String type
    );

}

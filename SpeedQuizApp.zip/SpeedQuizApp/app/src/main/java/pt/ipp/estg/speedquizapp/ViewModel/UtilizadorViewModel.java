package pt.ipp.estg.speedquizapp.ViewModel;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;

import pt.ipp.estg.speedquizapp.Database.F1Database;
import pt.ipp.estg.speedquizapp.Perfil.Utilizador;
import pt.ipp.estg.speedquizapp.Repositorio.F1Repository;

import java.util.List;

public class UtilizadorViewModel extends AndroidViewModel {

    private F1Database f1Database;

    private F1Repository f1Repository;

    private LiveData<List<Utilizador>> utilizadorList;

    public UtilizadorViewModel(@NonNull Application application) {
        super(application);

        f1Database = F1Database.getInstance(this.getApplication());
        f1Repository =new F1Repository(application);

        utilizadorList= f1Database.utilizadorDao().getUtilizador();
    }

    public LiveData<List<Utilizador>> getUtilizadorList() {

        return utilizadorList;
    }

    public F1Database getF1Database() {

        return f1Database;
    }

    public void insert(Utilizador utilizador) { f1Repository.insertUtilizador(utilizador); }

    public void update(Utilizador utilizador) { f1Repository.updateUtilizador(utilizador); }

    public void delete(Utilizador utilizador) { f1Repository.deleteUtilizador(utilizador); }
}

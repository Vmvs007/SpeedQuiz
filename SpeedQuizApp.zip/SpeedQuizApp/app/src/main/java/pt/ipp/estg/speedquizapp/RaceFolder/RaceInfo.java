package pt.ipp.estg.speedquizapp.RaceFolder;

public class RaceInfo {
    private float lat;
    private float lon;
    private String display_name;

    public RaceInfo(float lat, float lon, String display_name) {
        this.lat = lat;
        this.lon = lon;
        this.display_name = display_name;
    }

    public float getLat() {
        return lat;
    }

    public void setLat(float lat) {
        this.lat = lat;
    }

    public float getLon() {
        return lon;
    }

    public void setLon(float lon) {
        this.lon = lon;
    }

    public String getDisplay_name() {
        return display_name;
    }

    public void setDisplay_name(String display_name) {
        this.display_name = display_name;
    }
}

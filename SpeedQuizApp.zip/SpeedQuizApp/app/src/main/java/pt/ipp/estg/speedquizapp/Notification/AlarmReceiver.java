package pt.ipp.estg.speedquizapp.Notification;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;

public class AlarmReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        Intent service1 = new Intent(context, NotificationService.class);
        service1.setData((Uri.parse("custom://" + System.currentTimeMillis())));
        service1.putExtra("idMed", intent.getIntExtra("idMed", 0));
        service1.putExtra("nameMed",intent.getStringExtra("nameMed"));
        context.startService(service1);
    }
}

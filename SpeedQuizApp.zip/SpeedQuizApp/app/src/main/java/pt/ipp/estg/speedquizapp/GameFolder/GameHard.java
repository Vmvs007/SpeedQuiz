package pt.ipp.estg.speedquizapp.GameFolder;

import android.content.Context;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.fragment.app.Fragment;

import java.util.Arrays;
import java.util.Collections;

import pt.ipp.estg.speedquizapp.R;

public class GameHard extends Fragment implements View.OnClickListener{

    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    private Context mContext;

    private View mContentView;

    private int cartasViradas = 0;
    private int pontos = 0;

    private ImageButton primeiraCartaVirada;
    private ImageButton segundaCartaVirada;
    private ImageButton btn0;
    private ImageButton btn1;
    private ImageButton btn2;
    private ImageButton btn3;
    private ImageButton btn4;
    private ImageButton btn5;
    private ImageButton btn6;
    private ImageButton btn7;
    private ImageButton btn8;
    private ImageButton btn9;
    private ImageButton btn10;
    private ImageButton btn11;
    private ImageButton btn12;
    private ImageButton btn13;
    private ImageButton btn14;
    private ImageButton btn15;
    private ImageButton btn16;
    private ImageButton btn17;
    private ImageButton btn18;
    private ImageButton btn19;
    private ImageButton btn20;
    private ImageButton btn21;
    private ImageButton btn22;
    private ImageButton btn23;
    private TextView txtPontos;

    private int car0 =  R.drawable.car0;
    private int car1 = R.drawable.car1;
    private int car2 = R.drawable.car2;
    private int car3 = R.drawable.car3;
    private int car4 =  R.drawable.car4;
    private int car5 =  R.drawable.car5;
    private int car6 =  R.drawable.car6;
    private int car7 =  R.drawable.car7;
    private int car8 =  R.drawable.car8;
    private int car9 =  R.drawable.car9;
    private int car10 =  R.drawable.car10;
    private int car11 =  R.drawable.car11;

    private ImageButton botoes[];
    private int imagens[];

    private static int TIME_OUT_ALL = 2000;
    private static int TIME_OUT_ANSWER = 300;






    private OnFragmentInteractionListener mListener;

    public GameHard() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment Fragment1.
     */
    // TODO: Rename and change types and number of parameters
    public static GameHard newInstance(String param1, String param2) {
        GameHard fragment = new GameHard();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
        mContext=getActivity();




    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment

        mContentView = inflater.inflate(R.layout.game_hard, container, false);

        btn0 =  (ImageButton) mContentView.findViewById(R.id.btn0);
        btn1 =  (ImageButton) mContentView.findViewById(R.id.btn1);
        btn2 =  (ImageButton) mContentView.findViewById(R.id.btn2);
        btn3 =  (ImageButton) mContentView.findViewById(R.id.btn3);
        btn4 =  (ImageButton) mContentView.findViewById(R.id.btn4);
        btn5 =  (ImageButton) mContentView.findViewById(R.id.btn5);
        btn6 =  (ImageButton) mContentView.findViewById(R.id.btn6);
        btn7 =  (ImageButton) mContentView.findViewById(R.id.btn7);
        btn8 =  (ImageButton) mContentView.findViewById(R.id.btn8);
        btn9 =  (ImageButton) mContentView.findViewById(R.id.btn9);
        btn10 = (ImageButton) mContentView.findViewById(R.id.btn10);
        btn11 = (ImageButton) mContentView.findViewById(R.id.btn11);
        btn12 = (ImageButton) mContentView.findViewById(R.id.btn12);
        btn13 = (ImageButton) mContentView.findViewById(R.id.btn13);
        btn14 = (ImageButton) mContentView.findViewById(R.id.btn14);
        btn15 = (ImageButton) mContentView.findViewById(R.id.btn15);
        btn16 = (ImageButton) mContentView.findViewById(R.id.btn16);
        btn17 = (ImageButton) mContentView.findViewById(R.id.btn17);
        btn18 = (ImageButton) mContentView.findViewById(R.id.btn18);
        btn19 = (ImageButton) mContentView.findViewById(R.id.btn19);
        btn20 = (ImageButton) mContentView.findViewById(R.id.btn20);
        btn21 = (ImageButton) mContentView.findViewById(R.id.btn21);
        btn22 = (ImageButton) mContentView.findViewById(R.id.btn22);
        btn23 = (ImageButton) mContentView.findViewById(R.id.btn23);
        txtPontos = (TextView) mContentView.findViewById(R.id.txtPontos);

        botoes = new ImageButton[] {btn0,btn1,btn2,btn3,btn4,btn5,btn6,btn7,btn8,btn9,btn10,btn11,btn12,btn13,btn14,btn15,btn16,btn17,btn18,btn19,btn20,btn21,btn22,btn23};
        imagens = new int[]{car0,car1,car2,car3,car4,car5,car6,car7,car8,car9,car10,car11,car0,car1,car2,car3,car4,car5,car6,car7,car8,car9,car10,car11};

        setButtonListener();
        show();

        new Handler().postDelayed(new Runnable() {

            @Override
            public void run() {
                hide();
            }
        }, TIME_OUT_ALL);

        Button refresh=(Button) mContentView.findViewById(R.id.button2);
        refresh.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                turnAllCard();
                show();
                resetPlacar();

                new Handler().postDelayed(new Runnable() {

                    @Override
                    public void run() {
                        hide();
                        setAllClickable();
                    }
                }, TIME_OUT_ALL);
            }
        });


        return mContentView;
    }
    public void setButtonListener() {
        for (int i = 0; i < botoes.length; i++){
            botoes[i].setOnClickListener(this);
        }
    }

    public void show() {
        Collections.shuffle(Arrays.asList(imagens));
        Collections.shuffle(Arrays.asList(botoes));

        for(int i = 0 ; i < botoes.length; i++) {
            botoes[i].setBackgroundResource(imagens[i]);
        }
    }

    public void hide() {
        for(int i = 0 ; i < botoes.length; i++) {
            botoes[i].setImageResource(R.drawable.capa);
        }
    }



    @Override
    public void onClick( View v) {
        ImageButton cartaTocada = (ImageButton) v;

        if(cartasViradas == 0) {
            primeiraCartaVirada = cartaTocada;
            turnCard(cartaTocada);
            cartasViradas = 1;
            primeiraCartaVirada.setClickable(false);

        }else {
            segundaCartaVirada = cartaTocada;
            cartasViradas = 0;
            turnCard(segundaCartaVirada);
            segundaCartaVirada.setClickable(false);

            if(verify(primeiraCartaVirada, segundaCartaVirada)) {
                pontos++;
                setPlacar();
            }
            else {
                //setAllNotClickable();
                pontos--;
                setPlacar();
                primeiraCartaVirada.setClickable(true);
                segundaCartaVirada.setClickable(true);

                new Handler().postDelayed(new Runnable() {

                    @Override
                    public void run() {

                        unturnCard(primeiraCartaVirada, segundaCartaVirada);
                        //setAllClickable();
                    }
                }, TIME_OUT_ANSWER);
            }
        }
    }
    private void turnCard(ImageButton cartaTocada)    {
        cartaTocada.setImageResource(0);
    }

    private void turnAllCard()    {
        for(int i = 0 ; i < botoes.length; i++) {
            botoes[i].setImageResource(0);
        }
    }

    public void  setPlacar()
    {
        if(pontos > 0)
            txtPontos.setTextColor(Color.GREEN);
        else if(pontos == 0)
            txtPontos.setTextColor(Color.BLACK);
        else
            txtPontos.setTextColor(Color.RED);

        txtPontos.setText("Points: " + pontos);
    }

    public void resetPlacar(){
        pontos=0;
        txtPontos.setTextColor(Color.BLACK);
        txtPontos.setText("Points: " + pontos);
    }

    private boolean verify(ImageButton carta1, ImageButton carta2) {
        if(carta1.getBackground().getConstantState().equals(carta2.getBackground().getConstantState()))
            return true;
        else
            return false;
    }

    public void unturnCard(ImageButton carta1, ImageButton carta2) {
        carta1.setImageResource(R.drawable.capa);
        carta2.setImageResource(R.drawable.capa);
    }

    public void setAllNotClickable(){
        for (int i = 0; i < botoes.length; i++){
            botoes[i].setClickable(false);
        }
    }

    public void setAllClickable(){
        for (int i = 0; i < botoes.length; i++){
            botoes[i].setClickable(true);
        }
    }




    // TODO: Rename method, update argument and hook method into UI event
    public void onButtonPressed(String notif) {
        if (mListener != null) {
        }
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {/*
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");*/
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }
    public interface OnFragmentInteractionListener {
        void onButtonclick(String notif);
    }




}

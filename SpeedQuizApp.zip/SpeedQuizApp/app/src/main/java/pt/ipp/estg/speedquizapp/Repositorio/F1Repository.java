package pt.ipp.estg.speedquizapp.Repositorio;

import android.app.Application;

import androidx.lifecycle.LiveData;


import pt.ipp.estg.speedquizapp.Dao.UtilizadorDao;
import pt.ipp.estg.speedquizapp.Database.F1Database;
import pt.ipp.estg.speedquizapp.Perfil.Utilizador;

import java.util.List;

public class F1Repository {

    private LiveData<List<Utilizador>> utilizadorList;
    private UtilizadorDao uDao;

    public F1Repository(Application application) {
        F1Database db = F1Database.getInstance(application);

        uDao=db.utilizadorDao();
        utilizadorList=uDao.getUtilizador();

    }

    public LiveData<List<Utilizador>> getAllUtilizador() {
        return utilizadorList;
    }


    public void insertUtilizador(Utilizador util) {
        F1Database.databaseWriteExecutor.execute(() -> {
            uDao.addUtilizador(util);
        });
    }

    public void deleteUtilizador(Utilizador util) {
        F1Database.databaseWriteExecutor.execute(() -> {
            uDao.deleteUtilizador(util);
        });
    }

    public void updateUtilizador( Utilizador util) {
        F1Database.databaseWriteExecutor.execute(() -> {
            uDao.updateUtilizador(util);
        });
    }
}

package pt.ipp.estg.speedquizapp.RaceFolder;

import androidx.room.Entity;
import androidx.room.Ignore;
import androidx.room.PrimaryKey;

@Entity
public class Race {

    @PrimaryKey(autoGenerate = true)
    private int id_medicamento;
    private String nome;
    private int quantidade;
    private int intervalo_tempo;
    private String data_toma;


    @Ignore
    public Race(int id_medicamento, String nome, int quantidade, int intervalo_tempo, String data_toma) {
        this.id_medicamento = id_medicamento;
        this.nome = nome;
        this.quantidade = quantidade;
        this.intervalo_tempo = intervalo_tempo;
        this.data_toma=data_toma;
    }

    public Race() {
    }

    public int getId_medicamento() {
        return id_medicamento;
    }

    public void setId_medicamento(int id_medicamtento) {
        this.id_medicamento = id_medicamtento;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(int quantidade) {
        this.quantidade = quantidade;
    }

    public int getIntervalo_tempo() {
        return intervalo_tempo;
    }

    public void setIntervalo_tempo(int intervalo_tempo) {
        this.intervalo_tempo = intervalo_tempo;
    }

    public String getData_toma() {
        return data_toma;
    }

    public void setData_toma(String data_toma) {
        this.data_toma = data_toma;
    }

    @Override
    public String toString() {
        return "Race{" +
                "id_medicamtento=" + id_medicamento +
                ", nome='" + nome + '\'' +
                ", quantidade=" + quantidade +
                ", intervalo_tempo=" + intervalo_tempo +
                ", data:toma=" + data_toma +
                '}';
    }
}

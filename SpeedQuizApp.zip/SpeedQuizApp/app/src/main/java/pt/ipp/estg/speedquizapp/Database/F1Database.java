package pt.ipp.estg.speedquizapp.Database;


import android.content.Context;

import androidx.annotation.NonNull;
import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import androidx.room.TypeConverters;
import androidx.room.migration.Migration;
import androidx.sqlite.db.SupportSQLiteDatabase;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import pt.ipp.estg.speedquizapp.Dao.UtilizadorDao;
import pt.ipp.estg.speedquizapp.Date.Convert;
import pt.ipp.estg.speedquizapp.Perfil.Utilizador;

@Database(entities = {Utilizador.class},
        version = 1)
@TypeConverters(Convert.class)
public abstract class F1Database extends RoomDatabase {

    private static final String DB_NAME= "F1Database.db";
    private static F1Database INSTANCE;
    private static final int NUMBER_OF_THREADS = 4;
    public static final ExecutorService databaseWriteExecutor =
            Executors.newFixedThreadPool(NUMBER_OF_THREADS);

    public static void destroyInstance() {
        INSTANCE=null;
    }

    public abstract UtilizadorDao utilizadorDao();

    static final Migration MIGRATION_1_2= new Migration(1,2) {
        @Override
        public void migrate(@NonNull SupportSQLiteDatabase database) {

        }
    };

    public static F1Database getInstance(Context context){

        if(INSTANCE==null){
            INSTANCE=Room.databaseBuilder(context.getApplicationContext(),
                    F1Database.class,DB_NAME)
                    .addMigrations(MIGRATION_1_2)
                    .fallbackToDestructiveMigration()
                    .addCallback(sRoomDatabaseCallback)
                    .build();

        }
        return INSTANCE;
    }

    private static RoomDatabase.Callback sRoomDatabaseCallback =
            new RoomDatabase.Callback(){

                @Override
                public void onOpen (@NonNull SupportSQLiteDatabase db){
                    super.onCreate(db);
                    /*

                    databaseWriteExecutor.execute(()-> {
                        WordDao dao= INSTANCE.wordDao();
                        //dao.deleteAll();

                        Word word= new Word("Hello");
                        dao.insert(word);
                        word= new Word ("World");
                        dao.insert(word);
                    });

                     */
                }
            };

}

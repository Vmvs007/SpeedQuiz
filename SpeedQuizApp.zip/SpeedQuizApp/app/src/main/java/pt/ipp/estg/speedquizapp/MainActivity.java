package pt.ipp.estg.speedquizapp;

import android.os.Bundle;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;


public class MainActivity extends AppCompatActivity {

    private static int SPLASH_TIME_OUT=3000;
    private ImageView logo;
    private Animation rotation;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.welcome);


        rotation= AnimationUtils.loadAnimation(this, R.anim.rotation);

        logo=(ImageView) findViewById(R.id.imageView);

        logo.startAnimation(rotation);

        setContentView(R.layout.activity_fire_base_auth);
        //startActivity(new Intent(this, FireBaseAuth.class));
        //Intent intent = new Intent(getApplicationContext(), FireBaseAuth.class);
        //startActivity(intent);

    }

    @Override
    public void onBackPressed() {

    }
}
package pt.ipp.estg.speedquizapp.Notification;

import android.app.IntentService;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.BitmapFactory;
import android.os.Build;
import android.util.Log;

import androidx.core.app.NotificationCompat;

import pt.ipp.estg.speedquizapp.R;


public class NotificationService extends IntentService {

    private NotificationManager notificationManager;
    private PendingIntent pendingIntent;
    private static int NOTIFICATION_ID = 1;
    Notification notification;
    private String titulo;
    private String texto = "Take your medicine!";

    public NotificationService() {
        super("IntentService");
    }


    @Override
    protected void onHandleIntent(Intent intent) {
        titulo=intent.getStringExtra("nameMed");

        NotificationCompat.Builder builder=getNotificationBuilder();


        NotificationManager mNotifyMgr = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);

        mNotifyMgr.notify(NOTIFICATION_ID, builder.build());

        Log.i("notif","Notifications sent.");

    }

    private NotificationCompat.Builder getNotificationBuilder(){
        //Intent intent = new Intent(getApplicationContext(), .class);
        //intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        //PendingIntent pendingIntent = PendingIntent.getActivity(getApplicationContext(), 0, intent, 0);
        createNotificationChannel();

        Resources res = this.getResources();

        NotificationCompat.Builder builder = new NotificationCompat.Builder(getApplicationContext(), "asd")
                .setSmallIcon(R.drawable.speedlogo)
                .setLargeIcon(BitmapFactory.decodeResource(res, R.drawable.speedlogo))
                .setContentTitle(titulo)
                .setContentText(texto)
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                .setContentIntent(pendingIntent)
                .setAutoCancel(true);

        return builder;
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            CharSequence name = getString(R.string.channel_name);
            String description = getString(R.string.channel_description);
            int importance = NotificationManager.IMPORTANCE_DEFAULT;
            NotificationChannel channel = new NotificationChannel("asd", name, importance);
            channel.setDescription(description);
            NotificationManager notificationManager = getSystemService(NotificationManager.class);
            notificationManager.createNotificationChannel(channel);
        }
    }

}

